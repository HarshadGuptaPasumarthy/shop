import React, {Component} from 'react'
import Header from '../components/Header'
import Footer from '../components/Footer'

class MyOrdersPage extends Component{
    render(){
        return(
            <React.Fragment>
                <Header/>
                <h1>My Orders - Not implemented</h1>
                <Footer/>
            </React.Fragment>
        )
    }
}

export default MyOrdersPage;